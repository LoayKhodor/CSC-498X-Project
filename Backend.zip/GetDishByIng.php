<?php
include("connection.php");
$values = explode(",", $_GET['ing']);

$query = "SELECT DISTINCT name, D.rid FROM dishes AS D,recipe_ingredients AS R WHERE D.rid = R.rid AND R.Ringredient=\"".$values[0]."\"";
for ($x = 1; $x < count($values); $x++) {
  $query .= " OR R.Ringredient=\"".$values[$x]."\"";
}


$stmt = $connection->prepare($query);

//$stmt ->bind_param(str_repeat("s",count($values)), $values);

//$stmt ->bind_param(str_repeat("s",count($values)),implode(", ", &($values)));

$stmt->execute();
$result = $stmt->get_result();
$temp_array=[];
while($row = $result->fetch_assoc()){
$temp_array[] = $row;
}
$json = json_encode($temp_array);
print $json;
?>