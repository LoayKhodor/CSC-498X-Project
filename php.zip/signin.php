<?php
include("connection.php");
$values = explode(",", $_GET['login'] ?? "");
$name = $values[0];
$password = hash("sha256",$values[1]);

$query = "SELECT * FROM users WHERE username =? AND password=?";
$stmt = $connection->prepare($query);
$stmt ->bind_param("ss",$name, $password);
$stmt->execute();
$result = $stmt->get_result();
$temp_array=[];
while($row = $result->fetch_assoc()){
$temp_array[] = $row;
}
$json = json_encode($temp_array);
print $json;
?>